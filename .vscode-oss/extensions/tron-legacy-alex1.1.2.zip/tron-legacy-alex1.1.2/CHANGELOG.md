# Change Log
All notable changes to the "tron-legacy" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## 1.0.3
- Add highlight for go imports

## 1.0.2
- Update screenshot

## 1.0.1
- Fix some JSX stuff

## 1.0.0
- Initial release
